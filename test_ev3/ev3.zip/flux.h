

#ifndef INCLUDED_FLUX_H
#define INCLUDED_FLUX_H

#include "api.h"

char* listenSocket();
int sendSocket(char msg[]);


#endif
