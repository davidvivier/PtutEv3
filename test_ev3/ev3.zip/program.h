

#ifndef INCLUDED_PROGRAM_H
#define INCLUDED_PROGRAM_H

#include <time.h>
#include "api.h"
#include "ev3.h"
#include "flux.h"

int run();
int testSensor(int sensor);
int robot();
void programmetest();

#endif